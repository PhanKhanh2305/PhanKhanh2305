﻿using Microsoft.EntityFrameworkCore;
using MVC21BITV01.Models;
namespace MVC21BITV01.NewFolder
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<ChiTietHD> ChiTietHDs { get; set; }
        public DbSet<HangHoa> HangHoas { get; set; }
        public DbSet<HoaDon> HoaDons { get; set; }
        public DbSet<Loai> Loais { get; set; }
    }
}


﻿namespace MVC21BITV01.Models
{
    public class HangHoa
    {
        public int MaHH { get; set; }
        public string TenHH { get; set; }
        public string TenAlias { get; set; }
        public int MaLoai { get; set; }
        public string MoTaDonVi { get; set; }
        public double? DonGia { get; set; }
        public string Hinh { get; set; }
        public DateTime NgaySX { get; set; }
        public double GiamGia { get; set; }
        public int SoLanXem { get; set; }
        public string MoTa { get; set; }
        public string MaNCC { get; set; }

        public Loai Loai { get; set; }
    }
}

﻿namespace MVC21BITV01.Models
{
    public class Loai
    {
        public int MaLoai { get; set; }
        public string TenLoai { get; set; }
        public string TenLoaiAlias { get; set; }
        public string MoTa { get; set; }
        public string Hinh { get; set; }

        public ICollection<HangHoa> HangHoas { get; set; }
    }
}

﻿namespace MVC21BITV01.Models
{
    public class ChiTietHD
    {
        public int MaCT { get; set; }
        public int MaHD { get; set; }
        public int MaHH { get; set; }
        public double DonGia { get; set; }
        public int SoLuong { get; set; }
        public double GiamGia { get; set; }

        public HoaDon HoaDon { get; set; }
        public HangHoa HangHoa { get; set; }
    }
}

﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace MVC21BITV01.ViewModels
{
    public class HangHoaViewModel
    {
        [Required]
        public string TenHH { get; set; }

        [Required]
        public int MaLoai { get; set; }

        public string MoTaDonVi { get; set; }

        public double? DonGia { get; set; }

        [Required]
        public DateTime NgaySX { get; set; }

        public double GiamGia { get; set; }

        public string MoTa { get; set; }

        [Required]
        public string MaNCC { get; set; }

        public IFormFile Hinh { get; set; }

        public IEnumerable<SelectListItem> LoaiList { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using MVC21BITV01.NewFolder;
using MVC21BITV01.Models;
using MVC21BITV01.ViewModels;
namespace MVC21BITV01.Controllers
{
    public class HangHoaController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HangHoaController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Create()
        {
            var loaiList = _context.Loais.Select(l => new SelectListItem
            {
                Value = l.MaLoai.ToString(),
                Text = l.TenLoai
            }).ToList();

            var viewModel = new HangHoaViewModel
            {
                LoaiList = loaiList
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(HangHoaViewModel model)
        {
            if (ModelState.IsValid)
            {
                var hangHoa = new HangHoa
                {
                    TenHH = model.TenHH,
                    MaLoai = model.MaLoai,
                    MoTaDonVi = model.MoTaDonVi,
                    DonGia = model.DonGia,
                    NgaySX = model.NgaySX,
                    GiamGia = model.GiamGia,
                    MoTa = model.MoTa,
                    MaNCC = model.MaNCC,
                    SoLanXem = 0,
                    Hinh = await SaveFile(model.Hinh)
                };

                _context.HangHoas.Add(hangHoa);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            model.LoaiList = _context.Loais.Select(l => new SelectListItem
            {
                Value = l.MaLoai.ToString(),
                Text = l.TenLoai
            }).ToList();

            return View(model);
        }

        private async Task<string> SaveFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return null;
            }

            var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "Hinh/HangHoa");
            var uniqueFileName = Guid.NewGuid().ToString() + "_" + file.FileName;
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(fileStream);
            }

            return uniqueFileName;
        }
    }
}
